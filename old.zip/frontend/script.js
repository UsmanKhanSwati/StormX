document.addEventListener("DOMContentLoaded", function () {
    const chatBox = document.getElementById("chat-box");
    const chatHistoryList = document.getElementById("chat-history");
    const sidebar = document.getElementById("sidebar");
    const toggleButton = document.getElementById("toggle-sidebar");
    const newChatButton = document.getElementById("new-chat");

    let allChats = JSON.parse(localStorage.getItem("chatHistory")) || [];
    let currentChatIndex = -1;
    let currentChat = [];

    function init() {
        if (allChats.length === 0) {
            promptNewChat();
        } else {
            loadChatHistory();
            loadChat(allChats.length - 1);
        }
    }

    function promptNewChat() {
        let chatTitle = prompt("Enter chat name:");
        if (!chatTitle) chatTitle = `Chat ${allChats.length + 1}`;

        currentChat = [];
        allChats.push({ title: chatTitle, messages: [] });
        currentChatIndex = allChats.length - 1;
        saveChat();
        loadChatHistory();
        chatBox.innerHTML = "";
    }

    function loadChatHistory() {
        chatHistoryList.innerHTML = "";
        allChats.forEach((chat, index) => {
            const li = document.createElement("li");
            li.textContent = chat.title;
            li.onclick = () => loadChat(index);

            // Highlight the active chat
            if (currentChatIndex === index) {
                li.classList.add("active");
            }

            chatHistoryList.appendChild(li);
        });
    }

    function saveChat() {
        allChats[currentChatIndex].messages = currentChat;
        localStorage.setItem("chatHistory", JSON.stringify(allChats));
        loadChatHistory();
    }

    function loadChat(index) {
        chatBox.innerHTML = "";
        currentChatIndex = index;
        currentChat = allChats[index].messages;
        currentChat.forEach(msg => appendMessageToUI(msg.sender, msg.text, msg.isCode));
    }

    function appendMessage(sender, message, isCode = false) {
        currentChat.push({ sender, text: message, isCode });
        saveChat();
        appendMessageToUI(sender, message, isCode);
    }

    function appendMessageToUI(sender, message, isCode) {
        const div = document.createElement("div");
        div.className = `message-bubble ${sender}`;
        div.innerHTML = isCode ? formatCodeBlock(message) : formatText(message);
        chatBox.appendChild(div);
        
        scrollToBottom(); // 👈 Auto-scroll fix applied here
    }

    function scrollToBottom() {
        setTimeout(() => {
            chatBox.scrollTop = chatBox.scrollHeight;
        }, 100); // Delay to ensure rendering before scroll
    }

    function formatText(text) {
        return text.replace(/\*\*(.*?)\*\*/g, "<b>$1</b>")
                   .replace(/## (.*?)\n/g, "<h2>$1</h2>")
                   .replace(/### (.*?)\n/g, "<h3>$1</h3>")
                   .replace(/^- (.*?)$/gm, "<li>$1</li>")
                   .replace(/(<li>.*<\/li>)/g, "<ul>$1</ul>")
                   .replace(/\n/g, "<br>");
    }

    function formatCodeBlock(code) {
        const cleanCode = code.replace(/```[a-z]*\n/, "").replace(/```$/, "").trim();
        return `<div class="code-container">
                    <pre><code class="highlighted">${escapeHTML(cleanCode)}</code></pre>
                    <button onclick="copyCode(this)">Copy Code</button>
                </div>`;
    }

    function escapeHTML(html) {
        const div = document.createElement("div");
        div.innerText = html;
        return div.innerHTML;
    }

    async function sendMessage() {
        const input = document.getElementById("user-message");
        const message = input.value.trim();
        if (!message) return;

        input.value = "";
        appendMessage("user", `You: ${message}`);

        appendLoading();

        try {
            const response = await fetch("http://localhost:5099/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message })
            });

            const data = await response.json();
            removeLoading();

            const isCode = data.response.includes("```");
            appendMessage("ai", `AI: ${data.response}`, isCode);
        } catch (err) {
            removeLoading();
            console.error("Error fetching:", err);
        }
    }

    function appendLoading() {
        const div = document.createElement("div");
        div.className = "message-bubble ai loading";
        div.innerHTML = "⏳ AI is thinking...";
        chatBox.appendChild(div);
        
        scrollToBottom(); // 👈 Ensure loading message is visible
    }

    function removeLoading() {
        const loading = chatBox.querySelector(".loading");
        if (loading) chatBox.removeChild(loading);
        
        scrollToBottom(); // 👈 Ensure AI's response is visible
    }

    window.copyCode = function (btn) {
        const code = btn.previousElementSibling.textContent;
        navigator.clipboard.writeText(code).then(() => {
            btn.innerText = "Copied!";
            setTimeout(() => btn.innerText = "Copy Code", 1500);
        });
    };

    window.clearAllChats = function () {
        localStorage.clear();
        allChats = [];
        currentChat = [];
        chatBox.innerHTML = "";
        loadChatHistory();
        promptNewChat();
    };

    window.startListening = function () {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = "en-US";
        recognition.start();

        recognition.onresult = (e) => {
            document.getElementById("user-message").value = e.results[0][0].transcript;
            sendMessage();
        };

        recognition.onerror = (e) => {
            alert("Speech recognition error: " + e.error);
        };
    };

    window.handleKeyPress = function (e) {
        if (e.key === "Enter") sendMessage();
    };

    toggleButton.onclick = () => sidebar.classList.toggle("open");
    newChatButton.onclick = () => promptNewChat();
    
    init();
});
